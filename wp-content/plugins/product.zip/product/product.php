<?php
/*
plugin Name : Product
Plugin URI : http://localhost/wordpress-practical-tatvasoft/
Author : Priyanka patil
*/

?>